Change Log
==========


Version 1.2.0 *(2017-03-10)*
----------------------------
 
 * Fix: memory leak


Version 1.0.0 *(2017-02-14)*
----------------------------

Initial release.
