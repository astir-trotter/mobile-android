package com.tuyenmonkey.mkloader.type;

import android.graphics.Canvas;

/**
 * Created by Tuyen Monkey on 3/13/17.
 */

public class Balloon extends LoaderView {
  @Override public void initializeObjects() {

  }

  @Override public void setUpAnimation() {

  }

  @Override public void draw(Canvas canvas) {

  }
}
