package com.tuyenmonkey.mkloader.callback;

/**
 * Created by Tuyen Nguyen on 2/11/17.
 */

public interface InvalidateListener {
  void reDraw();
}
