package com.liuguangqiang.cookie;

/**
 * Created by Eric on 2017/3/3.
 */
public interface OnActionClickListener {

  void onClick();

}
