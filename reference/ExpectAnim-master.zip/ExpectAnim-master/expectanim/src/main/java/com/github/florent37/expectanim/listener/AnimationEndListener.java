package com.github.florent37.expectanim.listener;

import com.github.florent37.expectanim.ExpectAnim;

/**
 * Created by florentchampigny on 21/02/2017.
 */

public interface AnimationEndListener {
    void onAnimationEnd(ExpectAnim expectAnim);
}
