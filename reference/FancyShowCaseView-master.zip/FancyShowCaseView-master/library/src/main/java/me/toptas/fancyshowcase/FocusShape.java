package me.toptas.fancyshowcase;

/**
 * Created by ftoptas on 22/03/17.
 */

public enum FocusShape {
    CIRCLE,
    ROUNDED_RECTANGLE
}
