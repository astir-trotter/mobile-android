package com.yalantis.jellytoolbar.widget

/**
 * Created by irinagalata on 11/23/16.
 */
interface JellyWidget {

    fun collapse()

    fun expand()

    fun init() {}

    fun expandImmediately()

}