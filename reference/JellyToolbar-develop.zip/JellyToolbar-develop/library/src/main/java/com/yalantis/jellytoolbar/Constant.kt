package com.yalantis.jellytoolbar

/**
 * Created by irinagalata on 11/24/16.
 */
object Constant {

    const val ANIMATION_DURATION = 1100L

}