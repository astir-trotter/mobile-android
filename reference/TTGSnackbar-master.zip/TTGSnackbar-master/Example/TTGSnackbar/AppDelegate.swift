//
//  AppDelegate.swift
//  TTGSnackbar
//
//  Created by zekunyan on 10/07/2016.
//  Copyright (c) 2016 zekunyan. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}

