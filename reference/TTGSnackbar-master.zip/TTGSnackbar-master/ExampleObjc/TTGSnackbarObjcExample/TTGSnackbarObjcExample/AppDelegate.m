//
//  AppDelegate.m
//  TTGSnackbarObjcExample
//
//  Created by tutuge on 2016/12/13.
//  Copyright © 2016年 tutuge. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
